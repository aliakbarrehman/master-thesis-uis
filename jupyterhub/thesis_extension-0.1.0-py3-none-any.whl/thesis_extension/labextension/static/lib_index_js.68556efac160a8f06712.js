"use strict";
(self["webpackChunkthesis_extension"] = self["webpackChunkthesis_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/DataBlock.js":
/*!**************************!*\
  !*** ./lib/DataBlock.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/api */ "./lib/utils/api.js");
var __rest = (undefined && undefined.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};


const DataBlock = (_a) => {
    var { commands, isAdmin, mspId } = _a, props = __rest(_a, ["commands", "isAdmin", "mspId"]);
    const [dataList, setDataList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        (0,_utils_api__WEBPACK_IMPORTED_MODULE_1__.getAllData)("UiSMSP").then(response => {
            setDataList(response);
        });
        setInterval(() => {
            (0,_utils_api__WEBPACK_IMPORTED_MODULE_1__.getAllData)("UiSMSP").then(response => {
                setDataList(response);
            });
        }, 30000);
    }, []);
    const useData = async (event) => {
        const id = event.target.name;
        await (0,_utils_api__WEBPACK_IMPORTED_MODULE_1__.getData)(id, mspId);
        const payload = {
            action: 'lease',
            to: 'uio'
        };
        (0,_utils_api__WEBPACK_IMPORTED_MODULE_1__.leaseData)(id, mspId, payload).then((response) => {
            if (response.status == 'Accepted') {
                alert("Data Leased.");
            }
            else {
                alert("Failed to submit transaction");
            }
        });
        // get data here
        // create directory structure
        // create a file with credentials
        // update with lease
        console.log(commands);
        console.log(event);
        debugger;
        // const model = await commands.commands.commands.execute('docmanager:new-untitled', {
        //   // path: cwd,
        //   type: 'file',
        //   ext: 'py',
        // });
        // console.log(model);
    };
    // const editData = () => {
    // };
    const deleteDatablock = (event) => {
        const id = event.target.name;
        (0,_utils_api__WEBPACK_IMPORTED_MODULE_1__.deleteData)(id, mspId).then((response) => {
            if (response.status == 'Accepted') {
                alert("Transaction to delete submitted.");
            }
            else {
                alert("Failed to submit transaction");
            }
        });
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, dataList.map((dataBlock) => {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'data-block', key: dataBlock.id },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'data-title' }, dataBlock.title),
            dataBlock.lease == null || dataBlock.lease == "" ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'lease-tag open' }, "Open") : react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'lease-tag used' }, "In Use"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'data-description' }, dataBlock.description),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'button-group' },
                dataBlock.lease == null || dataBlock.lease == "" ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: 'button', name: dataBlock.id, onClick: useData }, "Use Data") : react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null),
                isAdmin ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: 'button', name: dataBlock.id, onClick: deleteDatablock }, "Delete Data") : react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null))));
    })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DataBlock);


/***/ }),

/***/ "./lib/DataForm.js":
/*!*************************!*\
  !*** ./lib/DataForm.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/api */ "./lib/utils/api.js");
var __rest = (undefined && undefined.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};


const DataForm = (_a) => {
    var { mspId } = _a, props = __rest(_a, ["mspId"]);
    const [dataBlock, setDataBlock] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [storageType, setStorageType] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [storageTypeDetails, setStorageTypeDetails] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const updateDataBlock = (field, value) => {
        let updateDataBlock = Object.assign({}, dataBlock);
        updateDataBlock[field] = value;
        setDataBlock(updateDataBlock);
    };
    const updateStorageTypeDetails = (field, value) => {
        let updateStorageTypeDetails = Object.assign({}, storageTypeDetails);
        updateStorageTypeDetails[field] = value;
        setStorageTypeDetails(updateStorageTypeDetails);
    };
    const getOwner = () => {
        return mspId.slice(0, 3).toLowerCase();
    };
    const addData = () => {
        const finalDataBlock = Object.assign({}, dataBlock);
        finalDataBlock['storageType'] = storageType;
        finalDataBlock[storageType] = storageTypeDetails;
        finalDataBlock['owner'] = getOwner();
        finalDataBlock['type'] = 'data';
        const payload = {
            'payload': finalDataBlock
        };
        console.log(payload);
        (0,_utils_api__WEBPACK_IMPORTED_MODULE_1__.postData)(payload, mspId).then((response) => {
            if (response.status == 'Accepted') {
                alert("Transaction Submitted.");
                setDataBlock(null);
                setStorageType('');
                setStorageTypeDetails(null);
            }
            else {
                alert("Failed to submit transaction");
            }
        });
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'input-group' },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'label' }, "Data Title"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: 'text', className: 'text-input', value: dataBlock === null || dataBlock === void 0 ? void 0 : dataBlock.title, onChange: (e) => updateDataBlock('title', e.target.value) })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'input-group' },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'label' }, "Data Description"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: 'text', className: 'text-input', value: dataBlock === null || dataBlock === void 0 ? void 0 : dataBlock.description, onChange: (e) => updateDataBlock('description', e.target.value) })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'input-group' },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'label' }, "Storage Type"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: 'dropdown', value: storageType, onChange: (e) => setStorageType(e.target.value) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: 'none' }, "Select Storage Type"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: 'azure' }, "Azure"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: 'local' }, "Local"))),
        storageType === 'azure' ?
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'input-group' },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'label' }, "Storage Account Name"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: 'text', className: 'text-input', value: storageTypeDetails === null || storageTypeDetails === void 0 ? void 0 : storageTypeDetails.name, onChange: (e) => updateStorageTypeDetails('name', e.target.value) })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'input-group' },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'label' }, "Storage Account Key"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: 'text', className: 'text-input', value: storageTypeDetails === null || storageTypeDetails === void 0 ? void 0 : storageTypeDetails.key, onChange: (e) => updateStorageTypeDetails('key', e.target.value) })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'input-group' },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'label' }, "Fileshare Name"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: 'text', className: 'text-input', value: storageTypeDetails === null || storageTypeDetails === void 0 ? void 0 : storageTypeDetails.fileshareName, onChange: (e) => updateStorageTypeDetails('fileshareName', e.target.value) }))) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null),
        storageType === 'local' ?
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'input-group' },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'label' }, "Hostname"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: 'text', className: 'text-input', value: storageTypeDetails === null || storageTypeDetails === void 0 ? void 0 : storageTypeDetails.hostname, onChange: (e) => updateStorageTypeDetails('hostname', e.target.value) })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'input-group' },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'label' }, "Hostpath"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: 'text', className: 'text-input', value: storageTypeDetails === null || storageTypeDetails === void 0 ? void 0 : storageTypeDetails.path, onChange: (e) => updateStorageTypeDetails('path', e.target.value) }))) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'input-group' },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: 'button', onClick: addData }, "Add Data"))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DataForm);


/***/ }),

/***/ "./lib/RootComponent.js":
/*!******************************!*\
  !*** ./lib/RootComponent.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RootWidget": () => (/* binding */ RootWidget),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _DataBlock__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./DataBlock */ "./lib/DataBlock.js");
/* harmony import */ var _DataForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./DataForm */ "./lib/DataForm.js");




const RootComponent = (commands) => {
    const [isAdmin, setIsAdmin] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [mspId, setMspId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('UiSMSP');
    debugger;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'input-group' },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'label' }, "MSP ID"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: 'text', className: 'text-input', onChange: (e) => setMspId(e.target.value) })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: 'input-group' },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: 'label' }, "Is Admin"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: 'checkbox', className: 'admin-selector', onChange: () => setIsAdmin(!isAdmin) })),
        isAdmin ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_DataForm__WEBPACK_IMPORTED_MODULE_2__["default"], { mspId: mspId }) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_DataBlock__WEBPACK_IMPORTED_MODULE_3__["default"], { commands: commands, mspId: mspId, isAdmin: isAdmin })));
};
class RootWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    /**
     * Constructs a new CounterWidget.
     */
    constructor(commands) {
        super();
        this.addClass('jp-ReactWidget');
        this.commands = commands;
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(RootComponent, { commands: this.commands });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RootWidget);


/***/ }),

/***/ "./lib/icons.js":
/*!**********************!*\
  !*** ./lib/icons.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "extensionIcon": () => (/* binding */ extensionIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_icons_hyperledger_icon_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../style/icons/hyperledger-icon.svg */ "./style/icons/hyperledger-icon.svg");


const extensionIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'thesis-extension:hyperledger',
    svgstr: _style_icons_hyperledger_icon_svg__WEBPACK_IMPORTED_MODULE_1__["default"]
});


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _RootComponent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./RootComponent */ "./lib/RootComponent.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./icons */ "./lib/icons.js");




// import { requestAPI } from './handler';
/**
 * Initialization data for the thesis-extension extension.
 */
const plugin = {
    id: 'thesis-extension:plugin',
    autoStart: true,
    optional: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__.ILauncher],
    activate: (app, launcher) => {
        const { commands } = app;
        const command = "thesis-extension";
        commands.addCommand(command, {
            caption: 'Data Explorer',
            label: 'Data Explorer',
            icon: _icons__WEBPACK_IMPORTED_MODULE_2__.extensionIcon,
            execute: () => {
                const content = new _RootComponent__WEBPACK_IMPORTED_MODULE_3__["default"](commands);
                const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.MainAreaWidget({ content });
                widget.title.label = "Data Explorer";
                widget.title.icon = _icons__WEBPACK_IMPORTED_MODULE_2__.extensionIcon;
                app.shell.add(widget, 'main');
            }
        });
        if (launcher) {
            launcher.add({
                command,
                category: 'Other',
                rank: 1,
            });
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/utils/api.js":
/*!**************************!*\
  !*** ./lib/utils/api.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deleteData": () => (/* binding */ deleteData),
/* harmony export */   "getAllData": () => (/* binding */ getAllData),
/* harmony export */   "getData": () => (/* binding */ getData),
/* harmony export */   "getJob": () => (/* binding */ getJob),
/* harmony export */   "getTransaction": () => (/* binding */ getTransaction),
/* harmony export */   "leaseData": () => (/* binding */ leaseData),
/* harmony export */   "postData": () => (/* binding */ postData)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "webpack/sharing/consume/default/axios/axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const HOST = 'http://localhost:3000';
// Get List of all data
const getAllData = async (wallet) => {
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${HOST}/data`, {
            headers: {
                'Content-Type': 'application/json',
                "walletid": wallet
            }
        });
        return response.data;
    }
    catch (error) {
        console.error(error);
        return [];
    }
};
// Get a single data block
const getData = async (id, wallet) => {
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${HOST}/data/${id}`, {
            headers: {
                'Content-Type': 'application/json',
                "walletid": wallet
            }
        });
        return response.data;
    }
    catch (error) {
        console.error(error);
        return {};
    }
};
// Lease Data block
const leaseData = async (id, wallet, data) => {
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${HOST}/data/lease/${id}`, data, {
            headers: {
                'Content-Type': 'application/json',
                "walletid": wallet
            },
            data: data
        });
        return response.data;
    }
    catch (error) {
        console.error(error);
        return null;
    }
};
// Post a single data block
const postData = async (data, wallet) => {
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${HOST}/data`, data, {
            headers: {
                'Content-Type': 'application/json',
                "walletid": wallet
            },
            data: data
        });
        console.log(response);
        return response.data;
    }
    catch (error) {
        console.error(error);
        return {};
    }
};
// Get Job
const getJob = async (id) => {
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${HOST}/job/${id}`, {
            headers: {
                'Content-Type': 'application/json'
            }
        });
        return response.data;
    }
    catch (error) {
        console.error(error);
        return {};
    }
};
// Get Transaction
const getTransaction = async (id, wallet) => {
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${HOST}/transaction/${id}`, {
            headers: {
                'Content-Type': 'application/json',
                "walletid": wallet
            }
        });
        return response.data;
    }
    catch (error) {
        console.error(error);
        return {};
    }
};
// Delete Data Block
const deleteData = async (id, wallet) => {
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`${HOST}/data/${id}`, {
            headers: {
                'Content-Type': 'application/json',
                "walletid": wallet
            }
        });
        return response.data;
    }
    catch (error) {
        console.error(error);
        return {};
    }
};



/***/ }),

/***/ "./style/icons/hyperledger-icon.svg":
/*!******************************************!*\
  !*** ./style/icons/hyperledger-icon.svg ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n   xmlns:cc=\"http://creativecommons.org/ns#\"\n   xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   id=\"Layer_1\"\n   data-name=\"Layer 1\"\n   viewBox=\"0 0 64 64\"\n   version=\"1.1\"\n   sodipodi:docname=\"hyperledger-icon.svg\"\n   width=\"64\"\n   height=\"64\"\n   inkscape:version=\"0.92.4 (5da689c313, 2019-01-14)\">\n  <metadata\n     id=\"metadata73\">\n    <rdf:RDF>\n      <cc:Work\n         rdf:about=\"\">\n        <dc:format>image/svg+xml</dc:format>\n        <dc:type\n           rdf:resource=\"http://purl.org/dc/dcmitype/StillImage\" />\n        <dc:title>hyperledger</dc:title>\n      </cc:Work>\n    </rdf:RDF>\n  </metadata>\n  <sodipodi:namedview\n     pagecolor=\"#ffffff\"\n     bordercolor=\"#666666\"\n     borderopacity=\"1\"\n     objecttolerance=\"10\"\n     gridtolerance=\"10\"\n     guidetolerance=\"10\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pageshadow=\"2\"\n     inkscape:window-width=\"1920\"\n     inkscape:window-height=\"1001\"\n     id=\"namedview71\"\n     showgrid=\"false\"\n     inkscape:zoom=\"4.794184\"\n     inkscape:cx=\"57.732727\"\n     inkscape:cy=\"42.995743\"\n     inkscape:window-x=\"-9\"\n     inkscape:window-y=\"-9\"\n     inkscape:window-maximized=\"1\"\n     inkscape:current-layer=\"Layer_1\" />\n  <defs\n     id=\"defs4\">\n    <style\n       id=\"style2\">.cls-1{fill:#2f3134;}</style>\n  </defs>\n  <title\n     id=\"title6\">hyperledger</title>\n  <g\n     id=\"g967\"\n     transform=\"matrix(3.0313136,0,0,3.0313136,-30.313124,-58.939421)\">\n    <path\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       inkscape:connector-curvature=\"0\"\n       id=\"path8\"\n       d=\"m 16.015136,39.163556 a 0.099402,0.099402 0 0 1 -0.08092,-0.04177 l -5.915983,-8.377917 a 0.09925171,0.09925171 0 0 1 -0.0091,-0.09876 l 4.284801,-9.321244 a 0.09883142,0.09883142 0 0 1 0.08091,-0.05726 l 10.200523,-0.943468 a 0.09443495,0.09443495 0 0 1 0.09004,0.0415 l 5.915998,8.377779 a 0.09925935,0.09925935 0 0 1 0.0091,0.09876 l -4.284663,9.321523 a 0.09938416,0.09938416 0 0 1 -0.08092,0.05726 l -10.200671,0.943328 c -0.003,2.54e-4 -0.0061,2.54e-4 -0.0091,2.54e-4 z m -5.802016,-8.487467 5.84988,8.284417 10.086699,-0.932816 4.236809,-9.217512 -5.84988,-8.284414 -10.086559,0.932818 z m 16.002687,7.445104 z\"\n       class=\"cls-1\" />\n    <path\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       inkscape:connector-curvature=\"0\"\n       id=\"path10\"\n       d=\"m 15.979587,39.142257 -1.63727,-8.524262 -0.008,-9.319033 7.976934,2.347946 8.27169,5.145844 -6.143391,5.460796 z m -1.545978,-17.710787 0.0069,9.177121 1.610158,8.378195 8.331168,-4.813193 6.036195,-5.367014 -8.153427,-5.071988 z\"\n       class=\"cls-1\" />\n    <circle\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       id=\"circle12\"\n       r=\"0.29706484\"\n       cy=\"23.740612\"\n       cx=\"22.442188\"\n       class=\"cls-1\" />\n    <path\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       inkscape:connector-curvature=\"0\"\n       id=\"path14\"\n       d=\"m 22.442212,24.353576 a 0.61295605,0.61295605 0 1 1 0.612347,-0.613025 0.61348077,0.61348077 0 0 1 -0.612347,0.613025 z m 0,-0.63073 -0.0184,0.0177 a 0.01818957,0.01818957 0 0 0 0.0184,0.01783 z\"\n       class=\"cls-1\" />\n    <circle\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       id=\"circle16\"\n       r=\"0.29706484\"\n       cy=\"34.198711\"\n       cx=\"24.42532\"\n       class=\"cls-1\" />\n    <path\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       inkscape:connector-curvature=\"0\"\n       id=\"path18\"\n       d=\"m 24.425282,34.811797 a 0.61302737,0.61302737 0 1 1 0.612472,-0.613014 0.61336615,0.61336615 0 0 1 -0.612472,0.613014 z m 0,-0.63073 -0.01826,0.0177 a 0.01803928,0.01803928 0 0 0 0.01826,0.0177 z\"\n       class=\"cls-1\" />\n    <circle\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       id=\"circle20\"\n       r=\"0.29706484\"\n       cy=\"39.064545\"\n       cx=\"16.087811\"\n       class=\"cls-1\" />\n    <path\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       inkscape:connector-curvature=\"0\"\n       id=\"path22\"\n       d=\"m 16.087751,39.677559 a 0.61302482,0.61302482 0 1 1 0.612472,-0.613025 0.61336615,0.61336615 0 0 1 -0.612472,0.613025 z m 0,-0.630731 -0.01825,0.0177 a 0.01803928,0.01803928 0 0 0 0.01825,0.0177 z\"\n       class=\"cls-1\" />\n    <circle\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       id=\"circle24\"\n       r=\"0.29706484\"\n       cy=\"30.707779\"\n       cx=\"14.383887\"\n       class=\"cls-1\" />\n    <path\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       inkscape:connector-curvature=\"0\"\n       id=\"path26\"\n       d=\"m 14.383951,31.320651 a 0.61288727,0.61288727 0 1 1 0.612335,-0.612747 0.61341964,0.61341964 0 0 1 -0.612335,0.612747 z m 0,-0.63073 -0.0184,0.01798 a 0.01825325,0.01825325 0 0 0 0.0184,0.0177 z\"\n       class=\"cls-1\" />\n    <circle\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       id=\"circle28\"\n       r=\"0.29706484\"\n       cy=\"28.814528\"\n       cx=\"30.500488\"\n       class=\"cls-1\" />\n    <path\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       inkscape:connector-curvature=\"0\"\n       id=\"path30\"\n       d=\"m 30.500483,29.427365 a 0.61288727,0.61288727 0 1 1 0.612472,-0.612748 0.61341964,0.61341964 0 0 1 -0.612472,0.612748 z m 0,-0.630728 -0.01826,0.01798 a 0.01803928,0.01803928 0 0 0 0.01826,0.0177 z\"\n       class=\"cls-1\" />\n    <circle\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       id=\"circle32\"\n       r=\"0.29706484\"\n       cy=\"21.365255\"\n       cx=\"14.383887\"\n       class=\"cls-1\" />\n    <path\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       inkscape:connector-curvature=\"0\"\n       id=\"path34\"\n       d=\"m 14.383951,21.978242 a 0.61295605,0.61295605 0 1 1 0.612335,-0.613025 0.61348077,0.61348077 0 0 1 -0.612335,0.613025 z m 0,-0.630731 -0.01841,0.01771 a 0.01818957,0.01818957 0 0 0 0.0184,0.01783 z\"\n       class=\"cls-1\" />\n    <path\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       inkscape:connector-curvature=\"0\"\n       id=\"path36\"\n       d=\"m 26.215807,38.220228 a 0.09762914,0.09762914 0 0 1 -0.03306,-0.0055 l -7.777625,-2.745616 -8.354538,-4.696174 a 0.09893076,0.09893076 0 0 1 -0.0184,-0.15934 l 6.285729,-5.759837 8.218857,-4.518847 a 0.09845189,0.09845189 0 0 1 0.08839,-0.0036 0.09959558,0.09959558 0 0 1 0.05602,0.06847 l 1.841426,8.095198 -0.207753,9.628453 a 0.09939945,0.09939945 0 0 1 -0.04274,0.07939 0.09840604,0.09840604 0 0 1 -0.05631,0.01742 z m -15.94889,-7.55299 8.219819,4.622032 7.632945,2.693052 0.207199,-9.467589 -1.809893,-7.942908 -8.084408,4.44181 z\"\n       class=\"cls-1\" />\n    <path\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       inkscape:connector-curvature=\"0\"\n       id=\"path38\"\n       d=\"m 24.457649,34.236117 -0.04053,-0.01383 -10.081857,-3.504978 0.0325,-0.02822 8.09077,-6.99543 z M 14.432641,30.698497 24.392915,34.161418 22.42591,23.78744 Z\"\n       class=\"cls-1\" />\n    <path\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       inkscape:connector-curvature=\"0\"\n       id=\"path40\"\n       d=\"M 18.373732,35.56148 16.25401,24.774753 26.619847,28.480985 Z m -1.858023,-10.482698 1.986937,10.110905 7.729346,-6.636777 z\"\n       class=\"cls-1\" />\n    <rect\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       id=\"rect42\"\n       transform=\"rotate(-29.32764)\"\n       height=\"4.0851278\"\n       width=\"0.1982971\"\n       y=\"25.672207\"\n       x=\"1.9765103\"\n       class=\"cls-1\" />\n    <polygon\n       transform=\"matrix(0.25472016,0,0,0.25472016,9.1807162,-1.2837356)\"\n       style=\"fill:#2f3134\"\n       id=\"polygon44\"\n       points=\"36.016,143.71 36.672,144.13 27.444,158.612 26.788,158.193 \"\n       class=\"cls-1\" />\n    <rect\n       style=\"fill:#2f3134;stroke-width:0.25472015\"\n       id=\"rect46\"\n       transform=\"rotate(-85.821779)\"\n       height=\"4.085434\"\n       width=\"0.19811116\"\n       y=\"28.433397\"\n       x=\"-26.614811\"\n       class=\"cls-1\" />\n  </g>\n</svg>\n");

/***/ })

}]);
//# sourceMappingURL=lib_index_js.68556efac160a8f06712.js.map