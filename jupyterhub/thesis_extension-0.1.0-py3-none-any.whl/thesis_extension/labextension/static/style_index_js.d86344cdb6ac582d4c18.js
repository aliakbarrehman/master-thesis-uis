"use strict";
(self["webpackChunkthesis_extension"] = self["webpackChunkthesis_extension"] || []).push([["style_index_js"],{

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n.jp-ReactWidget {\n    /* color: var(--jp-ui-font-color1);\n    background: var(--jp-layout-color1);\n    font-size: 48px;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    text-align: center; */\n}\n\n.data-block {\n    min-width: calc(50% - 4rem);\n    padding: 1rem;\n    margin: 1rem;\n    box-shadow: 0px 0px 10px #8888885e;\n    border-radius: 0.5rem;\n    position: relative;\n    min-height: 7rem;\n    display: inline-table;\n}\n\n.data-title {\n    color: #000000;\n    font-size: 2rem;\n    border-bottom: 1px solid #e7e7e7;\n    margin-bottom: 0.5rem;\n    padding-bottom: 4px;\n}\n\n.data-description {\n    text-align: justify;\n    color: #979797;\n}\n\n.lease-tag {\n    position: absolute;\n    top: 1rem;\n    right: 1rem;\n    padding: 5px;\n    border-radius: 5px;\n    font-size: 0.5rem;\n}\n.open {\n    background-color: #b1e9b1;\n}\n\n.used {\n    background-color: #e9b1b1;\n}\n\n.button-group {\n    margin: 1rem 0 0rem 0;\n}\n\n.button {\n    padding: 0.25rem;\n    border-radius: 5px;\n    border: none;\n    margin-right: 5px;\n    background-color: #153240;\n    color: white;\n}\n\n.button:hover {\n    padding: 0.25rem;\n    border-radius: 5px;\n    border: none;\n    margin-right: 5px;\n    background-color: rgb(199, 225, 230);\n    color: #153240;\n    cursor: pointer;\n}\n\n.input-group {\n    margin: 1rem;\n}\n\n.label {\n    display: inline-block;\n    min-width: 10rem;\n}\n\n.text-input {\n\n}\n\n.admin-selector {\n\n}\n\n.dropdown {\n\n}", "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;;CAIC;AACD;IACI;;;;;;yBAMqB;AACzB;;AAEA;IACI,2BAA2B;IAC3B,aAAa;IACb,YAAY;IACZ,kCAAkC;IAClC,qBAAqB;IACrB,kBAAkB;IAClB,gBAAgB;IAChB,qBAAqB;AACzB;;AAEA;IACI,cAAc;IACd,eAAe;IACf,gCAAgC;IAChC,qBAAqB;IACrB,mBAAmB;AACvB;;AAEA;IACI,mBAAmB;IACnB,cAAc;AAClB;;AAEA;IACI,kBAAkB;IAClB,SAAS;IACT,WAAW;IACX,YAAY;IACZ,kBAAkB;IAClB,iBAAiB;AACrB;AACA;IACI,yBAAyB;AAC7B;;AAEA;IACI,yBAAyB;AAC7B;;AAEA;IACI,qBAAqB;AACzB;;AAEA;IACI,gBAAgB;IAChB,kBAAkB;IAClB,YAAY;IACZ,iBAAiB;IACjB,yBAAyB;IACzB,YAAY;AAChB;;AAEA;IACI,gBAAgB;IAChB,kBAAkB;IAClB,YAAY;IACZ,iBAAiB;IACjB,oCAAoC;IACpC,cAAc;IACd,eAAe;AACnB;;AAEA;IACI,YAAY;AAChB;;AAEA;IACI,qBAAqB;IACrB,gBAAgB;AACpB;;AAEA;;AAEA;;AAEA;;AAEA;;AAEA;;AAEA","sourcesContent":["/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n.jp-ReactWidget {\n    /* color: var(--jp-ui-font-color1);\n    background: var(--jp-layout-color1);\n    font-size: 48px;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    text-align: center; */\n}\n\n.data-block {\n    min-width: calc(50% - 4rem);\n    padding: 1rem;\n    margin: 1rem;\n    box-shadow: 0px 0px 10px #8888885e;\n    border-radius: 0.5rem;\n    position: relative;\n    min-height: 7rem;\n    display: inline-table;\n}\n\n.data-title {\n    color: #000000;\n    font-size: 2rem;\n    border-bottom: 1px solid #e7e7e7;\n    margin-bottom: 0.5rem;\n    padding-bottom: 4px;\n}\n\n.data-description {\n    text-align: justify;\n    color: #979797;\n}\n\n.lease-tag {\n    position: absolute;\n    top: 1rem;\n    right: 1rem;\n    padding: 5px;\n    border-radius: 5px;\n    font-size: 0.5rem;\n}\n.open {\n    background-color: #b1e9b1;\n}\n\n.used {\n    background-color: #e9b1b1;\n}\n\n.button-group {\n    margin: 1rem 0 0rem 0;\n}\n\n.button {\n    padding: 0.25rem;\n    border-radius: 5px;\n    border: none;\n    margin-right: 5px;\n    background-color: #153240;\n    color: white;\n}\n\n.button:hover {\n    padding: 0.25rem;\n    border-radius: 5px;\n    border: none;\n    margin-right: 5px;\n    background-color: rgb(199, 225, 230);\n    color: #153240;\n    cursor: pointer;\n}\n\n.input-group {\n    margin: 1rem;\n}\n\n.label {\n    display: inline-block;\n    min-width: 10rem;\n}\n\n.text-input {\n\n}\n\n.admin-selector {\n\n}\n\n.dropdown {\n\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./style/base.css":
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./style/index.js":
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base.css */ "./style/base.css");



/***/ })

}]);
//# sourceMappingURL=style_index_js.d86344cdb6ac582d4c18.js.map